# SmartSpec Validate SPEC_INDEX Workflow
## Cross-Check SPEC_INDEX.json Integrity

---
description: |
  Validate SPEC_INDEX.json integrity and system health.
  
  Performs comprehensive validation including:
  - File existence checks
  - Broken reference detection
  - Circular dependency detection
  - Duplicate spec detection
  - Orphaned spec detection
  - Stale spec detection
  - Metadata consistency checks
  - Dependents calculation verification
  
  Generates detailed health report with actionable recommendations.
  Supports auto-fix for common issues.

flags:
  - name: --fix
    description: Automatically fix issues that can be auto-fixed (metadata, dependents)
    type: boolean
    default: false
  
  - name: --report
    description: Report detail level
    type: enum
    values: [summary, detailed]
    default: summary
  
  - name: --index
    description: Path to SPEC_INDEX.json file
    type: string
    default: .spec/SPEC_INDEX.json
  
  - name: --output
    description: Output report file path (optional, defaults to .spec/reports/)
    type: string
    optional: true

examples:
  - command: /smartspec_validate_index
    description: Validate with summary report
  
  - command: /smartspec_validate_index --fix
    description: Validate and auto-fix issues
  
  - command: /smartspec_validate_index --report=detailed
    description: Generate detailed validation report
  
  - command: /smartspec_validate_index --fix --report=detailed --output=validation.md
    description: Full validation with auto-fix and custom output

version: 1.0.0
author: SmartSpec Team
---

## Overview

This workflow validates SPEC_INDEX.json integrity and generates a comprehensive health report.

**Purpose:**
- Detect broken references, circular dependencies, duplicates
- Identify orphaned and stale specs
- Verify metadata consistency
- Calculate health score
- Provide actionable recommendations
- Auto-fix common issues

**When to Use:**
- Before major releases
- After bulk spec changes
- Weekly/monthly health checks
- When suspecting INDEX issues
- After team handover

**Expected Outcome:**
- Validation report (.md file)
- Health score (0-100)
- List of errors and warnings
- Recommendations for fixes
- Auto-fixed INDEX (if --fix flag)

---

## 0. Prerequisites

### 0.1 Check SPEC_INDEX Exists

```bash
# Resolve SPEC_INDEX path
INDEX_PATH="${FLAGS_index:-}"

if [ -z "$INDEX_PATH" ]; then
  if [ -f ".spec/SPEC_INDEX.json" ]; then
    INDEX_PATH=".spec/SPEC_INDEX.json"
  elif [ -f "SPEC_INDEX.json" ]; then
    INDEX_PATH="SPEC_INDEX.json"
  elif [ -f ".smartspec/SPEC_INDEX.json" ]; then # deprecated
    INDEX_PATH=".smartspec/SPEC_INDEX.json" # deprecated
  fi
fi

if [ ! -f "$INDEX_PATH" ]; then
  echo "❌ ERROR: SPEC_INDEX.json not found"
  echo ""
  echo "Checked (in order):"
  echo "  1) .spec/SPEC_INDEX.json (canonical)"
  echo "  2) SPEC_INDEX.json (legacy root mirror)"
  echo "  3) .smartspec/SPEC_INDEX.json (deprecated)"
  echo ""
  echo "Specify a custom path with:"
  echo "  /smartspec_validate_index --index=path/to/SPEC_INDEX.json"
  exit 1
fi

echo "✅ Found SPEC_INDEX at: $INDEX_PATH"
```

### 0.2 Load SPEC_INDEX

```javascript
const fs = require('fs');
const path = require('path');

// Load SPEC_INDEX
const indexPath = FLAGS.index || (fs.existsSync('.spec/SPEC_INDEX.json') ? '.spec/SPEC_INDEX.json' : (fs.existsSync('SPEC_INDEX.json') ? 'SPEC_INDEX.json' : (fs.existsSync('.smartspec/SPEC_INDEX.json') ? '.smartspec/SPEC_INDEX.json' : '.spec/SPEC_INDEX.json')));
const indexContent = fs.readFileSync(indexPath, 'utf-8');
let specIndex;

try {
  specIndex = JSON.parse(indexContent);
} catch (error) {
  console.error('❌ ERROR: Invalid JSON in SPEC_INDEX.json');
  console.error(error.message);
  process.exit(1);
}

console.log('✅ Loaded SPEC_INDEX.json');
console.log(`   Total specs: ${specIndex.specs?.length || 0}`);
```

### 0.3 Initialize Validation Results

```javascript
const validationResults = {
  timestamp: new Date().toISOString(),
  indexPath: indexPath,
  totalSpecs: specIndex.specs?.length || 0,
  checks: {
    fileExistence: { passed: true, errors: [], warnings: [] },
    brokenReferences: { passed: true, errors: [], warnings: [] },
    circularDependencies: { passed: true, errors: [], warnings: [] },
    duplicates: { passed: true, errors: [], warnings: [] },
    orphanedSpecs: { passed: true, errors: [], warnings: [] },
    staleSpecs: { passed: true, errors: [], warnings: [] },
    metadataConsistency: { passed: true, errors: [], warnings: [] },
    dependentsCalculation: { passed: true, errors: [], warnings: [] }
  },
  summary: {
    totalChecks: 8,
    passedChecks: 0,
    errors: 0,
    warnings: 0,
    healthScore: 100
  },
  autoFixes: [],
  recommendations: []
};

console.log('✅ Initialized validation results');
```

---

## 1. Validation Check 1: File Existence

**Purpose:** Verify that all spec files referenced in INDEX actually exist

### 1.1 Check Each Spec File

```javascript
console.log('\n🔍 Check 1: File Existence');
console.log('─'.repeat(50));

const fileExistenceErrors = [];

for (const spec of specIndex.specs) {
  const specPath = path.join(spec.path, 'spec.md');
  
  if (!fs.existsSync(specPath)) {
    fileExistenceErrors.push({
      type: 'file_not_found',
      specId: spec.id,
      specTitle: spec.title,
      expectedPath: specPath,
      message: `Spec file not found: ${specPath}`,
      suggestion: 'Remove from INDEX or create spec file',
      severity: 'error'
    });
  }
}

// Update results
validationResults.checks.fileExistence.errors = fileExistenceErrors;
validationResults.checks.fileExistence.passed = fileExistenceErrors.length === 0;

if (fileExistenceErrors.length === 0) {
  console.log('✅ All spec files exist');
} else {
  console.log(`❌ Found ${fileExistenceErrors.length} missing files`);
  fileExistenceErrors.forEach(err => {
    console.log(`   - ${err.specId}: ${err.expectedPath}`);
  });
}
```

---

## 2. Validation Check 2: Broken References

**Purpose:** Detect dependencies that reference non-existent specs

### 2.1 Build Spec ID Set

```javascript
console.log('\n🔍 Check 2: Broken References');
console.log('─'.repeat(50));

const specIds = new Set(specIndex.specs.map(s => s.id));
const brokenReferenceErrors = [];
```

### 2.2 Check Each Dependency

```javascript
for (const spec of specIndex.specs) {
  if (!spec.dependencies || spec.dependencies.length === 0) {
    continue;
  }
  
  for (const depId of spec.dependencies) {
    if (!specIds.has(depId)) {
      brokenReferenceErrors.push({
        type: 'broken_reference',
        specId: spec.id,
        specTitle: spec.title,
        missingDependency: depId,
        message: `${spec.id} references non-existent ${depId}`,
        suggestion: `Create ${depId} or remove reference from ${spec.id}`,
        severity: 'error'
      });
    }
  }
}

// Update results
validationResults.checks.brokenReferences.errors = brokenReferenceErrors;
validationResults.checks.brokenReferences.passed = brokenReferenceErrors.length === 0;

if (brokenReferenceErrors.length === 0) {
  console.log('✅ No broken references');
} else {
  console.log(`❌ Found ${brokenReferenceErrors.length} broken references`);
  brokenReferenceErrors.forEach(err => {
    console.log(`   - ${err.specId} → ${err.missingDependency}`);
  });
}
```

---

## 3. Validation Check 3: Circular Dependencies

**Purpose:** Detect circular dependency chains that cause deadlocks

### 3.1 Build Dependency Graph

```javascript
console.log('\n🔍 Check 3: Circular Dependencies');
console.log('─'.repeat(50));

// Build adjacency list
const graph = new Map();
for (const spec of specIndex.specs) {
  graph.set(spec.id, spec.dependencies || []);
}
```

### 3.2 Detect Cycles Using DFS

```javascript
function findCycles(graph) {
  const cycles = [];
  const visited = new Set();
  const recursionStack = new Set();
  
  function dfs(node, path) {
    if (recursionStack.has(node)) {
      // Found cycle
      const cycleStart = path.indexOf(node);
      const cycle = path.slice(cycleStart);
      cycle.push(node); // Complete the cycle
      cycles.push(cycle);
      return;
    }
    
    if (visited.has(node)) {
      return;
    }
    
    visited.add(node);
    recursionStack.add(node);
    
    const neighbors = graph.get(node) || [];
    for (const neighbor of neighbors) {
      if (graph.has(neighbor)) { // Only follow if neighbor exists
        dfs(neighbor, [...path, node]);
      }
    }
    
    recursionStack.delete(node);
  }
  
  // Start DFS from each node
  for (const node of graph.keys()) {
    if (!visited.has(node)) {
      dfs(node, []);
    }
  }
  
  return cycles;
}

const cycles = findCycles(graph);
const circularDependencyErrors = [];

for (const cycle of cycles) {
  const cycleStr = cycle.join(' → ');
  circularDependencyErrors.push({
    type: 'circular_dependency',
    cycle: cycle,
    message: `Circular dependency detected: ${cycleStr}`,
    suggestion: `Break the cycle by removing one dependency in the chain`,
    severity: 'error'
  });
}

// Update results
validationResults.checks.circularDependencies.errors = circularDependencyErrors;
validationResults.checks.circularDependencies.passed = circularDependencyErrors.length === 0;

if (circularDependencyErrors.length === 0) {
  console.log('✅ No circular dependencies');
} else {
  console.log(`❌ Found ${circularDependencyErrors.length} circular dependencies`);
  circularDependencyErrors.forEach(err => {
    console.log(`   - ${err.cycle.join(' → ')}`);
  });
}
```

---

## 4. Validation Check 4: Duplicate Detection

**Purpose:** Detect duplicate specs (by ID, path, or similar titles)

### 4.1 Check Duplicate IDs

```javascript
console.log('\n🔍 Check 4: Duplicate Detection');
console.log('─'.repeat(50));

const duplicateErrors = [];
const duplicateWarnings = [];

// Check duplicate IDs
const idCounts = {};
for (const spec of specIndex.specs) {
  idCounts[spec.id] = (idCounts[spec.id] || 0) + 1;
}

for (const [id, count] of Object.entries(idCounts)) {
  if (count > 1) {
    duplicateErrors.push({
      type: 'duplicate_id',
      specId: id,
      count: count,
      message: `Duplicate spec ID: ${id} (${count} occurrences)`,
      suggestion: 'Merge or rename duplicate specs',
      severity: 'error'
    });
  }
}
```

### 4.2 Check Duplicate Paths

```javascript
// Check duplicate paths
const pathCounts = {};
for (const spec of specIndex.specs) {
  pathCounts[spec.path] = (pathCounts[spec.path] || 0) + 1;
}

for (const [specPath, count] of Object.entries(pathCounts)) {
  if (count > 1) {
    const specs = specIndex.specs.filter(s => s.path === specPath);
    const specIds = specs.map(s => s.id).join(', ');
    
    duplicateErrors.push({
      type: 'duplicate_path',
      path: specPath,
      specIds: specIds,
      count: count,
      message: `Multiple specs at same path: ${specPath} (${specIds})`,
      suggestion: 'Move one spec to different path',
      severity: 'error'
    });
  }
}
```

### 4.3 Check Similar Titles (Levenshtein Distance)

```javascript
// Calculate Levenshtein distance
function levenshteinDistance(str1, str2) {
  const len1 = str1.length;
  const len2 = str2.length;
  const matrix = Array(len1 + 1).fill(null).map(() => Array(len2 + 1).fill(0));
  
  for (let i = 0; i <= len1; i++) matrix[i][0] = i;
  for (let j = 0; j <= len2; j++) matrix[0][j] = j;
  
  for (let i = 1; i <= len1; i++) {
    for (let j = 1; j <= len2; j++) {
      const cost = str1[i - 1] === str2[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + cost
      );
    }
  }
  
  return matrix[len1][len2];
}

function calculateSimilarity(str1, str2) {
  const distance = levenshteinDistance(str1.toLowerCase(), str2.toLowerCase());
  const maxLen = Math.max(str1.length, str2.length);
  return 1 - (distance / maxLen);
}

// Check similar titles
for (let i = 0; i < specIndex.specs.length; i++) {
  for (let j = i + 1; j < specIndex.specs.length; j++) {
    const spec1 = specIndex.specs[i];
    const spec2 = specIndex.specs[j];
    const similarity = calculateSimilarity(spec1.title, spec2.title);
    
    if (similarity > 0.8) { // 80% similar
      duplicateWarnings.push({
        type: 'similar_title',
        spec1Id: spec1.id,
        spec1Title: spec1.title,
        spec2Id: spec2.id,
        spec2Title: spec2.title,
        similarity: Math.round(similarity * 100),
        message: `Similar titles (${Math.round(similarity * 100)}% similar):\n` +
                 `  - ${spec1.id}: "${spec1.title}"\n` +
                 `  - ${spec2.id}: "${spec2.title}"`,
        suggestion: 'Review if these are duplicate specs',
        severity: 'warning'
      });
    }
  }
}

// Update results
validationResults.checks.duplicates.errors = duplicateErrors;
validationResults.checks.duplicates.warnings = duplicateWarnings;
validationResults.checks.duplicates.passed = duplicateErrors.length === 0;

if (duplicateErrors.length === 0 && duplicateWarnings.length === 0) {
  console.log('✅ No duplicates found');
} else {
  if (duplicateErrors.length > 0) {
    console.log(`❌ Found ${duplicateErrors.length} duplicate errors`);
  }
  if (duplicateWarnings.length > 0) {
    console.log(`⚠️  Found ${duplicateWarnings.length} similar titles`);
  }
}
```

---

## 5. Validation Check 5: Orphaned Specs

**Purpose:** Identify specs with no dependents and not referenced by any spec

### 5.1 Find Orphaned Specs

```javascript
console.log('\n🔍 Check 5: Orphaned Specs');
console.log('─'.repeat(50));

const orphanedWarnings = [];

for (const spec of specIndex.specs) {
  // Skip core specs (they're foundational)
  if (spec.id.includes('core')) {
    continue;
  }
  
  // Check if has dependents
  const hasDependents = spec.dependents && spec.dependents.length > 0;
  
  if (!hasDependents) {
    orphanedWarnings.push({
      type: 'orphaned_spec',
      specId: spec.id,
      specTitle: spec.title,
      status: spec.status,
      message: `${spec.id} is orphaned (no dependents, not referenced)`,
      suggestion: 'Review if this spec is still needed or should be deprecated',
      severity: 'warning'
    });
  }
}

// Update results
validationResults.checks.orphanedSpecs.warnings = orphanedWarnings;
validationResults.checks.orphanedSpecs.passed = orphanedWarnings.length === 0;

if (orphanedWarnings.length === 0) {
  console.log('✅ No orphaned specs');
} else {
  console.log(`⚠️  Found ${orphanedWarnings.length} orphaned specs`);
  orphanedWarnings.forEach(warn => {
    console.log(`   - ${warn.specId}`);
  });
}
```

---

## 6. Validation Check 6: Stale Specs

**Purpose:** Identify specs not updated for a long time

### 6.1 Find Stale Specs

```javascript
console.log('\n🔍 Check 6: Stale Specs');
console.log('─'.repeat(50));

const staleWarnings = [];
const STALE_THRESHOLD_DAYS = 180; // 6 months

for (const spec of specIndex.specs) {
  if (!spec.updated) {
    continue;
  }
  
  const updatedDate = new Date(spec.updated);
  const now = new Date();
  const daysSinceUpdate = Math.floor((now - updatedDate) / (1000 * 60 * 60 * 24));
  
  if (daysSinceUpdate > STALE_THRESHOLD_DAYS && spec.status === 'draft') {
    staleWarnings.push({
      type: 'stale_spec',
      specId: spec.id,
      specTitle: spec.title,
      daysSinceUpdate: daysSinceUpdate,
      lastUpdated: spec.updated,
      message: `${spec.id} not updated for ${daysSinceUpdate} days`,
      suggestion: 'Review and update or deprecate this spec',
      severity: 'warning'
    });
  }
}

// Update results
validationResults.checks.staleSpecs.warnings = staleWarnings;
validationResults.checks.staleSpecs.passed = staleWarnings.length === 0;

if (staleWarnings.length === 0) {
  console.log('✅ No stale specs');
} else {
  console.log(`⚠️  Found ${staleWarnings.length} stale specs`);
  staleWarnings.forEach(warn => {
    console.log(`   - ${warn.specId} (${warn.daysSinceUpdate} days)`);
  });
}
```

---

## 7. Validation Check 7: Metadata Consistency

**Purpose:** Verify metadata counts match actual data

### 7.1 Check Total Count

```javascript
console.log('\n🔍 Check 7: Metadata Consistency');
console.log('─'.repeat(50));

const metadataErrors = [];
const metadataFixes = [];

// Check total_specs
const actualCount = specIndex.specs.length;
const metadataCount = specIndex.metadata?.total_specs || 0;

if (actualCount !== metadataCount) {
  metadataErrors.push({
    type: 'metadata_count_mismatch',
    field: 'total_specs',
    actual: actualCount,
    metadata: metadataCount,
    message: `Metadata mismatch: actual count (${actualCount}) != metadata count (${metadataCount})`,
    suggestion: 'Run with --fix to update metadata',
    severity: 'error',
    autoFixable: true
  });
  
  if (FLAGS.fix) {
    specIndex.metadata.total_specs = actualCount;
    metadataFixes.push({
      type: 'fixed_total_specs',
      oldValue: metadataCount,
      newValue: actualCount,
      message: `Fixed total_specs: ${metadataCount} → ${actualCount}`
    });
  }
}
```

### 7.2 Check Status Counts

```javascript
// Check by_status counts
const actualByStatus = {};
for (const spec of specIndex.specs) {
  actualByStatus[spec.status] = (actualByStatus[spec.status] || 0) + 1;
}

const metadataByStatus = specIndex.metadata?.by_status || {};

// Compare
const allStatuses = new Set([
  ...Object.keys(actualByStatus),
  ...Object.keys(metadataByStatus)
]);

for (const status of allStatuses) {
  const actual = actualByStatus[status] || 0;
  const metadata = metadataByStatus[status] || 0;
  
  if (actual !== metadata) {
    metadataErrors.push({
      type: 'metadata_status_mismatch',
      field: `by_status.${status}`,
      actual: actual,
      metadata: metadata,
      message: `Status count mismatch for "${status}": actual (${actual}) != metadata (${metadata})`,
      suggestion: 'Run with --fix to update metadata',
      severity: 'error',
      autoFixable: true
    });
    
    if (FLAGS.fix) {
      if (!specIndex.metadata.by_status) {
        specIndex.metadata.by_status = {};
      }
      specIndex.metadata.by_status[status] = actual;
      metadataFixes.push({
        type: 'fixed_status_count',
        status: status,
        oldValue: metadata,
        newValue: actual,
        message: `Fixed by_status.${status}: ${metadata} → ${actual}`
      });
    }
  }
}
```

### 7.3 Check Repo Counts

```javascript
// Check by_repo counts
const actualByRepo = {};
for (const spec of specIndex.specs) {
  actualByRepo[spec.repo] = (actualByRepo[spec.repo] || 0) + 1;
}

const metadataByRepo = specIndex.metadata?.by_repo || {};

// Compare
const allRepos = new Set([
  ...Object.keys(actualByRepo),
  ...Object.keys(metadataByRepo)
]);

for (const repo of allRepos) {
  const actual = actualByRepo[repo] || 0;
  const metadata = metadataByRepo[repo] || 0;
  
  if (actual !== metadata) {
    metadataErrors.push({
      type: 'metadata_repo_mismatch',
      field: `by_repo.${repo}`,
      actual: actual,
      metadata: metadata,
      message: `Repo count mismatch for "${repo}": actual (${actual}) != metadata (${metadata})`,
      suggestion: 'Run with --fix to update metadata',
      severity: 'error',
      autoFixable: true
    });
    
    if (FLAGS.fix) {
      if (!specIndex.metadata.by_repo) {
        specIndex.metadata.by_repo = {};
      }
      specIndex.metadata.by_repo[repo] = actual;
      metadataFixes.push({
        type: 'fixed_repo_count',
        repo: repo,
        oldValue: metadata,
        newValue: actual,
        message: `Fixed by_repo.${repo}: ${metadata} → ${actual}`
      });
    }
  }
}

// Update results
validationResults.checks.metadataConsistency.errors = metadataErrors;
validationResults.checks.metadataConsistency.passed = metadataErrors.length === 0;
validationResults.autoFixes.push(...metadataFixes);

if (metadataErrors.length === 0) {
  console.log('✅ Metadata consistent');
} else {
  console.log(`❌ Found ${metadataErrors.length} metadata inconsistencies`);
  if (FLAGS.fix) {
    console.log(`✅ Fixed ${metadataFixes.length} metadata issues`);
  }
}
```

---

## 8. Validation Check 8: Dependents Calculation

**Purpose:** Verify dependents are correctly calculated

### 8.1 Recalculate Dependents

```javascript
console.log('\n🔍 Check 8: Dependents Calculation');
console.log('─'.repeat(50));

const dependentsErrors = [];
const dependentsFixes = [];

// Calculate correct dependents
const correctDependents = {};
for (const spec of specIndex.specs) {
  correctDependents[spec.id] = [];
}

for (const spec of specIndex.specs) {
  for (const depId of (spec.dependencies || [])) {
    if (correctDependents[depId]) {
      if (!correctDependents[depId].includes(spec.id)) {
        correctDependents[depId].push(spec.id);
      }
    }
  }
}

// Compare with current
for (const spec of specIndex.specs) {
  const current = (spec.dependents || []).sort();
  const correct = (correctDependents[spec.id] || []).sort();
  
  const currentStr = JSON.stringify(current);
  const correctStr = JSON.stringify(correct);
  
  if (currentStr !== correctStr) {
    dependentsErrors.push({
      type: 'dependents_mismatch',
      specId: spec.id,
      current: current,
      correct: correct,
      message: `Dependents mismatch for ${spec.id}:\n` +
               `  Current: [${current.join(', ')}]\n` +
               `  Correct: [${correct.join(', ')}]`,
      suggestion: 'Run with --fix to recalculate dependents',
      severity: 'error',
      autoFixable: true
    });
    
    if (FLAGS.fix) {
      spec.dependents = correct;
      dependentsFixes.push({
        type: 'fixed_dependents',
        specId: spec.id,
        oldValue: current,
        newValue: correct,
        message: `Fixed dependents for ${spec.id}`
      });
    }
  }
}

// Update results
validationResults.checks.dependentsCalculation.errors = dependentsErrors;
validationResults.checks.dependentsCalculation.passed = dependentsErrors.length === 0;
validationResults.autoFixes.push(...dependentsFixes);

if (dependentsErrors.length === 0) {
  console.log('✅ Dependents correctly calculated');
} else {
  console.log(`❌ Found ${dependentsErrors.length} dependents mismatches`);
  if (FLAGS.fix) {
    console.log(`✅ Fixed ${dependentsFixes.length} dependents`);
  }
}
```

---

## 9. Calculate Summary and Health Score

```javascript
console.log('\n📊 Calculating Summary');
console.log('─'.repeat(50));

// Count errors and warnings
let totalErrors = 0;
let totalWarnings = 0;
let passedChecks = 0;

for (const [checkName, checkResult] of Object.entries(validationResults.checks)) {
  totalErrors += checkResult.errors?.length || 0;
  totalWarnings += checkResult.warnings?.length || 0;
  if (checkResult.passed) {
    passedChecks++;
  }
}

validationResults.summary.passedChecks = passedChecks;
validationResults.summary.errors = totalErrors;
validationResults.summary.warnings = totalWarnings;

// Calculate health score
// Base: 100
// Deduct 5 points per error
// Deduct 1 point per warning
let healthScore = 100;
healthScore -= totalErrors * 5;
healthScore -= totalWarnings * 1;
healthScore = Math.max(0, healthScore); // Min 0

validationResults.summary.healthScore = healthScore;

// Determine status
let status = 'valid';
if (totalErrors > 0) {
  status = 'errors';
} else if (totalWarnings > 0) {
  status = 'warnings';
}

validationResults.summary.status = status;

console.log(`✅ Summary calculated`);
console.log(`   Status: ${status.toUpperCase()}`);
console.log(`   Health Score: ${healthScore}/100`);
console.log(`   Passed Checks: ${passedChecks}/${validationResults.summary.totalChecks}`);
console.log(`   Errors: ${totalErrors}`);
console.log(`   Warnings: ${totalWarnings}`);
```

---

## 10. Generate Recommendations

```javascript
console.log('\n💡 Generating Recommendations');
console.log('─'.repeat(50));

const recommendations = {
  highPriority: [],
  mediumPriority: [],
  lowPriority: []
};

// High priority: Errors
if (totalErrors > 0) {
  // Broken references
  const brokenRefs = validationResults.checks.brokenReferences.errors;
  if (brokenRefs.length > 0) {
    recommendations.highPriority.push({
      issue: 'Broken References',
      count: brokenRefs.length,
      action: 'Fix broken references by creating missing specs or removing invalid dependencies',
      examples: brokenRefs.slice(0, 3).map(e => `${e.specId} → ${e.missingDependency}`)
    });
  }
  
  // Circular dependencies
  const circular = validationResults.checks.circularDependencies.errors;
  if (circular.length > 0) {
    recommendations.highPriority.push({
      issue: 'Circular Dependencies',
      count: circular.length,
      action: 'Break circular dependency chains by removing one dependency in each cycle',
      examples: circular.slice(0, 3).map(e => e.cycle.join(' → '))
    });
  }
  
  // Duplicates
  const dupes = validationResults.checks.duplicates.errors;
  if (dupes.length > 0) {
    recommendations.highPriority.push({
      issue: 'Duplicate Specs',
      count: dupes.length,
      action: 'Merge or rename duplicate specs',
      examples: dupes.slice(0, 3).map(e => e.message)
    });
  }
  
  // Missing files
  const missing = validationResults.checks.fileExistence.errors;
  if (missing.length > 0) {
    recommendations.highPriority.push({
      issue: 'Missing Spec Files',
      count: missing.length,
      action: 'Create missing spec files or remove entries from INDEX',
      examples: missing.slice(0, 3).map(e => `${e.specId}: ${e.expectedPath}`)
    });
  }
}

// Medium priority: Warnings + Auto-fixable
if (totalWarnings > 0 || validationResults.autoFixes.length > 0) {
  // Metadata issues (auto-fixable)
  const metadata = validationResults.checks.metadataConsistency.errors;
  if (metadata.length > 0) {
    recommendations.mediumPriority.push({
      issue: 'Metadata Inconsistencies',
      count: metadata.length,
      action: 'Run with --fix flag to automatically update metadata',
      command: '/smartspec_validate_index --fix'
    });
  }
  
  // Dependents issues (auto-fixable)
  const dependents = validationResults.checks.dependentsCalculation.errors;
  if (dependents.length > 0) {
    recommendations.mediumPriority.push({
      issue: 'Dependents Calculation',
      count: dependents.length,
      action: 'Run with --fix flag to recalculate dependents',
      command: '/smartspec_validate_index --fix'
    });
  }
  
  // Orphaned specs
  const orphaned = validationResults.checks.orphanedSpecs.warnings;
  if (orphaned.length > 0) {
    recommendations.mediumPriority.push({
      issue: 'Orphaned Specs',
      count: orphaned.length,
      action: 'Review orphaned specs and deprecate if no longer needed',
      examples: orphaned.slice(0, 3).map(w => w.specId)
    });
  }
  
  // Stale specs
  const stale = validationResults.checks.staleSpecs.warnings;
  if (stale.length > 0) {
    recommendations.mediumPriority.push({
      issue: 'Stale Specs',
      count: stale.length,
      action: 'Review and update stale specs or deprecate them',
      examples: stale.slice(0, 3).map(w => `${w.specId} (${w.daysSinceUpdate} days)`)
    });
  }
}

// Low priority: Similar titles
const similar = validationResults.checks.duplicates.warnings;
if (similar.length > 0) {
  recommendations.lowPriority.push({
    issue: 'Similar Titles',
    count: similar.length,
    action: 'Review specs with similar titles to check for duplicates',
    examples: similar.slice(0, 3).map(w => `${w.spec1Id} vs ${w.spec2Id} (${w.similarity}%)`)
  });
}

validationResults.recommendations = recommendations;

console.log(`✅ Generated recommendations`);
console.log(`   High Priority: ${recommendations.highPriority.length}`);
console.log(`   Medium Priority: ${recommendations.mediumPriority.length}`);
console.log(`   Low Priority: ${recommendations.lowPriority.length}`);
```

---

## 11. Save Fixed SPEC_INDEX (if --fix)

```javascript
if (FLAGS.fix && validationResults.autoFixes.length > 0) {
  console.log('\n💾 Saving Fixed SPEC_INDEX');
  console.log('─'.repeat(50));
  
  // Update last_updated
  specIndex.last_updated = new Date().toISOString();
  
  // Update validation metadata
  if (!specIndex.metadata) {
    specIndex.metadata = {};
  }
  if (!specIndex.metadata.validation) {
    specIndex.metadata.validation = {};
  }
  
  specIndex.metadata.validation.last_validated = validationResults.timestamp;
  specIndex.metadata.validation.status = validationResults.summary.status;
  specIndex.metadata.validation.health_score = validationResults.summary.healthScore;
  
  // Save
  fs.writeFileSync(
    indexPath,
    JSON.stringify(specIndex, null, 2),
    'utf-8'
  );
  
  console.log(`✅ Saved fixed SPEC_INDEX.json`);
  console.log(`   Applied ${validationResults.autoFixes.length} fixes`);
}
```

---

## 12. Generate and Save Report

### 12.1 Determine Output Path

```javascript
console.log('\n📄 Generating Report');
console.log('─'.repeat(50));

let outputPath;
if (FLAGS.output) {
  outputPath = FLAGS.output;
} else {
  // Default: .spec/reports/validation-report-TIMESTAMP.md
  const reportsDir = '.smartspec/reports';
  if (!fs.existsSync(reportsDir)) {
    fs.mkdirSync(reportsDir, { recursive: true });
  }
  
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  outputPath = path.join(reportsDir, `validation-report-${timestamp}.md`);
}
```

### 12.2 Generate Report Content

**Report will be generated in next section (Part 2)**

---

**TO BE CONTINUED IN PART 2...**

This workflow file will be completed with:
- Section 12.2: Report generation (summary and detailed formats)
- Section 13: Output to console
- Section 14: Exit with appropriate code
- Examples and best practices

**Current Progress:** ~1200 lines  
**Estimated Total:** ~1500 lines

### 12.2 Generate Report Content

```javascript
let reportContent = '';

if (FLAGS.report === 'summary') {
  // Summary Report
  reportContent = generateSummaryReport(validationResults, specIndex);
} else {
  // Detailed Report
  reportContent = generateDetailedReport(validationResults, specIndex);
}

function generateSummaryReport(results, index) {
  const { summary, checks, recommendations, autoFixes } = results;
  
  let report = `# SPEC_INDEX Validation Report (Summary)

**Date:** ${new Date(results.timestamp).toLocaleString()}  
**SPEC_INDEX:** ${results.indexPath}  
**Total Specs:** ${results.totalSpecs}

---

## ✅ Summary

`;

  // Status badge
  if (summary.status === 'valid') {
    report += `- **Status:** ✅ VALID\n`;
  } else if (summary.status === 'warnings') {
    report += `- **Status:** ⚠️ WARNINGS FOUND\n`;
  } else {
    report += `- **Status:** ❌ ERRORS FOUND\n`;
  }
  
  report += `- **Health Score:** ${summary.healthScore}/100\n`;
  report += `- **Passed Checks:** ${summary.passedChecks}/${summary.totalChecks}\n`;
  report += `- **Errors:** ${summary.errors}\n`;
  report += `- **Warnings:** ${summary.warnings}\n`;
  
  if (autoFixes.length > 0) {
    report += `- **Auto-Fixes Applied:** ${autoFixes.length}\n`;
  }
  
  report += `\n---\n\n`;
  
  // Errors
  if (summary.errors > 0) {
    report += `## ❌ Errors (${summary.errors})\n\n`;
    
    let errorNum = 1;
    for (const [checkName, checkResult] of Object.entries(checks)) {
      if (checkResult.errors && checkResult.errors.length > 0) {
        for (const error of checkResult.errors) {
          report += `### ${errorNum}. ${error.type.replace(/_/g, ' ').toUpperCase()}\n`;
          report += `**Issue:** ${error.message}\n\n`;
          report += `**Suggestion:** ${error.suggestion}\n\n`;
          errorNum++;
        }
      }
    }
    
    report += `---\n\n`;
  }
  
  // Warnings
  if (summary.warnings > 0) {
    report += `## ⚠️ Warnings (${summary.warnings})\n\n`;
    
    let warnNum = 1;
    for (const [checkName, checkResult] of Object.entries(checks)) {
      if (checkResult.warnings && checkResult.warnings.length > 0) {
        for (const warning of checkResult.warnings) {
          report += `### ${warnNum}. ${warning.type.replace(/_/g, ' ').toUpperCase()}\n`;
          report += `**Issue:** ${warning.message}\n\n`;
          report += `**Suggestion:** ${warning.suggestion}\n\n`;
          warnNum++;
        }
      }
    }
    
    report += `---\n\n`;
  }
  
  // Passed Checks
  if (summary.passedChecks > 0) {
    report += `## ✅ Passed Checks (${summary.passedChecks})\n\n`;
    
    for (const [checkName, checkResult] of Object.entries(checks)) {
      if (checkResult.passed) {
        report += `- ✅ ${checkName.replace(/([A-Z])/g, ' $1').trim()}\n`;
      }
    }
    
    report += `\n---\n\n`;
  }
  
  // Auto-Fixes
  if (autoFixes.length > 0) {
    report += `## 🔧 Auto-Fixes Applied (${autoFixes.length})\n\n`;
    
    for (const fix of autoFixes) {
      report += `- ✅ ${fix.message}\n`;
    }
    
    report += `\n---\n\n`;
  }
  
  // Recommendations
  if (recommendations.highPriority.length > 0 || 
      recommendations.mediumPriority.length > 0 || 
      recommendations.lowPriority.length > 0) {
    
    report += `## 🎯 Recommendations\n\n`;
    
    // High Priority
    if (recommendations.highPriority.length > 0) {
      report += `### High Priority\n\n`;
      recommendations.highPriority.forEach((rec, i) => {
        report += `${i + 1}. **${rec.issue}** (${rec.count} issues)\n`;
        report += `   - Action: ${rec.action}\n`;
        if (rec.examples) {
          report += `   - Examples:\n`;
          rec.examples.forEach(ex => {
            report += `     - ${ex}\n`;
          });
        }
        report += `\n`;
      });
    }
    
    // Medium Priority
    if (recommendations.mediumPriority.length > 0) {
      report += `### Medium Priority\n\n`;
      recommendations.mediumPriority.forEach((rec, i) => {
        report += `${i + 1}. **${rec.issue}** (${rec.count} issues)\n`;
        report += `   - Action: ${rec.action}\n`;
        if (rec.command) {
          report += `   - Command: \`${rec.command}\`\n`;
        }
        if (rec.examples) {
          report += `   - Examples:\n`;
          rec.examples.forEach(ex => {
            report += `     - ${ex}\n`;
          });
        }
        report += `\n`;
      });
    }
    
    // Low Priority
    if (recommendations.lowPriority.length > 0) {
      report += `### Low Priority\n\n`;
      recommendations.lowPriority.forEach((rec, i) => {
        report += `${i + 1}. **${rec.issue}** (${rec.count} issues)\n`;
        report += `   - Action: ${rec.action}\n`;
        if (rec.examples) {
          report += `   - Examples:\n`;
          rec.examples.forEach(ex => {
            report += `     - ${ex}\n`;
          });
        }
        report += `\n`;
      });
    }
    
    report += `---\n\n`;
  }
  
  // Next Steps
  report += `## 🚀 Next Steps\n\n`;
  
  if (summary.errors > 0) {
    report += `### 1. Fix Errors (High Priority)\n\n`;
    report += `Review and fix all errors listed above.\n\n`;
  }
  
  if (autoFixes.length > 0 && !FLAGS.fix) {
    report += `### 2. Run Auto-Fix\n\n`;
    report += `\`\`\`bash\n`;
    report += `/smartspec_validate_index --fix\n`;
    report += `\`\`\`\n\n`;
  }
  
  if (summary.warnings > 0) {
    report += `### 3. Review Warnings\n\n`;
    report += `Review and address warnings as needed.\n\n`;
  }
  
  report += `### 4. Re-validate\n\n`;
  report += `After fixing issues, run validation again:\n\n`;
  report += `\`\`\`bash\n`;
  report += `/smartspec_validate_index\n`;
  report += `\`\`\`\n\n`;
  
  report += `---\n\n`;
  report += `**Report Generated:** ${new Date().toLocaleString()}\n`;
  
  return report;
}

function generateDetailedReport(results, index) {
  // Start with summary
  let report = generateSummaryReport(results, index);
  
  // Add detailed sections
  report += `\n---\n\n`;
  report += `# Detailed Validation Results\n\n`;
  
  // Check 1: File Existence
  report += `## Check 1: File Existence\n\n`;
  const fileCheck = results.checks.fileExistence;
  if (fileCheck.passed) {
    report += `✅ **PASSED** - All spec files exist\n\n`;
  } else {
    report += `❌ **FAILED** - ${fileCheck.errors.length} missing files\n\n`;
    report += `### Missing Files:\n\n`;
    fileCheck.errors.forEach((err, i) => {
      report += `${i + 1}. **${err.specId}** - ${err.specTitle}\n`;
      report += `   - Expected Path: \`${err.expectedPath}\`\n`;
      report += `   - Suggestion: ${err.suggestion}\n\n`;
    });
  }
  
  // Check 2: Broken References
  report += `## Check 2: Broken References\n\n`;
  const refCheck = results.checks.brokenReferences;
  if (refCheck.passed) {
    report += `✅ **PASSED** - No broken references\n\n`;
  } else {
    report += `❌ **FAILED** - ${refCheck.errors.length} broken references\n\n`;
    report += `### Broken References:\n\n`;
    refCheck.errors.forEach((err, i) => {
      report += `${i + 1}. **${err.specId}** → **${err.missingDependency}**\n`;
      report += `   - Spec: ${err.specTitle}\n`;
      report += `   - Missing Dependency: ${err.missingDependency}\n`;
      report += `   - Suggestion: ${err.suggestion}\n\n`;
    });
  }
  
  // Check 3: Circular Dependencies
  report += `## Check 3: Circular Dependencies\n\n`;
  const circCheck = results.checks.circularDependencies;
  if (circCheck.passed) {
    report += `✅ **PASSED** - No circular dependencies\n\n`;
  } else {
    report += `❌ **FAILED** - ${circCheck.errors.length} circular dependencies\n\n`;
    report += `### Circular Dependency Chains:\n\n`;
    circCheck.errors.forEach((err, i) => {
      report += `${i + 1}. ${err.cycle.join(' → ')}\n`;
      report += `   - Suggestion: ${err.suggestion}\n\n`;
    });
  }
  
  // Check 4: Duplicates
  report += `## Check 4: Duplicate Detection\n\n`;
  const dupCheck = results.checks.duplicates;
  if (dupCheck.passed && (!dupCheck.warnings || dupCheck.warnings.length === 0)) {
    report += `✅ **PASSED** - No duplicates found\n\n`;
  } else {
    if (dupCheck.errors && dupCheck.errors.length > 0) {
      report += `❌ **ERRORS** - ${dupCheck.errors.length} duplicate errors\n\n`;
      report += `### Duplicate Errors:\n\n`;
      dupCheck.errors.forEach((err, i) => {
        report += `${i + 1}. **${err.type.toUpperCase()}**\n`;
        report += `   - ${err.message}\n`;
        report += `   - Suggestion: ${err.suggestion}\n\n`;
      });
    }
    
    if (dupCheck.warnings && dupCheck.warnings.length > 0) {
      report += `⚠️ **WARNINGS** - ${dupCheck.warnings.length} similar titles\n\n`;
      report += `### Similar Titles:\n\n`;
      dupCheck.warnings.forEach((warn, i) => {
        report += `${i + 1}. **${warn.similarity}% Similar**\n`;
        report += `   - ${warn.spec1Id}: "${warn.spec1Title}"\n`;
        report += `   - ${warn.spec2Id}: "${warn.spec2Title}"\n`;
        report += `   - Suggestion: ${warn.suggestion}\n\n`;
      });
    }
  }
  
  // Check 5: Orphaned Specs
  report += `## Check 5: Orphaned Specs\n\n`;
  const orphCheck = results.checks.orphanedSpecs;
  if (orphCheck.passed) {
    report += `✅ **PASSED** - No orphaned specs\n\n`;
  } else {
    report += `⚠️ **WARNINGS** - ${orphCheck.warnings.length} orphaned specs\n\n`;
    report += `### Orphaned Specs:\n\n`;
    orphCheck.warnings.forEach((warn, i) => {
      report += `${i + 1}. **${warn.specId}** - ${warn.specTitle}\n`;
      report += `   - Status: ${warn.status}\n`;
      report += `   - Suggestion: ${warn.suggestion}\n\n`;
    });
  }
  
  // Check 6: Stale Specs
  report += `## Check 6: Stale Specs\n\n`;
  const staleCheck = results.checks.staleSpecs;
  if (staleCheck.passed) {
    report += `✅ **PASSED** - No stale specs\n\n`;
  } else {
    report += `⚠️ **WARNINGS** - ${staleCheck.warnings.length} stale specs\n\n`;
    report += `### Stale Specs:\n\n`;
    staleCheck.warnings.forEach((warn, i) => {
      report += `${i + 1}. **${warn.specId}** - ${warn.specTitle}\n`;
      report += `   - Last Updated: ${new Date(warn.lastUpdated).toLocaleDateString()}\n`;
      report += `   - Days Since Update: ${warn.daysSinceUpdate}\n`;
      report += `   - Suggestion: ${warn.suggestion}\n\n`;
    });
  }
  
  // Check 7: Metadata Consistency
  report += `## Check 7: Metadata Consistency\n\n`;
  const metaCheck = results.checks.metadataConsistency;
  if (metaCheck.passed) {
    report += `✅ **PASSED** - Metadata consistent\n\n`;
  } else {
    report += `❌ **FAILED** - ${metaCheck.errors.length} metadata inconsistencies\n\n`;
    report += `### Metadata Inconsistencies:\n\n`;
    metaCheck.errors.forEach((err, i) => {
      report += `${i + 1}. **${err.field}**\n`;
      report += `   - Actual: ${err.actual}\n`;
      report += `   - Metadata: ${err.metadata}\n`;
      report += `   - Auto-Fixable: ${err.autoFixable ? 'Yes' : 'No'}\n`;
      report += `   - Suggestion: ${err.suggestion}\n\n`;
    });
  }
  
  // Check 8: Dependents Calculation
  report += `## Check 8: Dependents Calculation\n\n`;
  const depCheck = results.checks.dependentsCalculation;
  if (depCheck.passed) {
    report += `✅ **PASSED** - Dependents correctly calculated\n\n`;
  } else {
    report += `❌ **FAILED** - ${depCheck.errors.length} dependents mismatches\n\n`;
    report += `### Dependents Mismatches:\n\n`;
    depCheck.errors.forEach((err, i) => {
      report += `${i + 1}. **${err.specId}**\n`;
      report += `   - Current: [${err.current.join(', ')}]\n`;
      report += `   - Correct: [${err.correct.join(', ')}]\n`;
      report += `   - Auto-Fixable: Yes\n`;
      report += `   - Suggestion: ${err.suggestion}\n\n`;
    });
  }
  
  report += `---\n\n`;
  report += `**Detailed Report Generated:** ${new Date().toLocaleString()}\n`;
  
  return report;
}

console.log(`✅ Generated ${FLAGS.report} report`);
```

### 12.3 Save Report

```javascript
fs.writeFileSync(outputPath, reportContent, 'utf-8');

console.log(`✅ Report saved to: ${outputPath}`);
```

---

## 13. Output to Console

### 13.1 Print Summary

```javascript
console.log('\n' + '='.repeat(60));
console.log('VALIDATION COMPLETE');
console.log('='.repeat(60));
console.log('');

// Status
if (validationResults.summary.status === 'valid') {
  console.log('✅ Status: VALID');
} else if (validationResults.summary.status === 'warnings') {
  console.log('⚠️  Status: WARNINGS FOUND');
} else {
  console.log('❌ Status: ERRORS FOUND');
}

console.log('');

// Metrics
console.log(`📊 Health Score: ${validationResults.summary.healthScore}/100`);
console.log(`✅ Passed Checks: ${validationResults.summary.passedChecks}/${validationResults.summary.totalChecks}`);
console.log(`❌ Errors: ${validationResults.summary.errors}`);
console.log(`⚠️  Warnings: ${validationResults.summary.warnings}`);

if (validationResults.autoFixes.length > 0) {
  console.log(`🔧 Auto-Fixes Applied: ${validationResults.autoFixes.length}`);
}

console.log('');

// Report location
console.log(`📄 Report: ${outputPath}`);

console.log('');
console.log('='.repeat(60));
```

### 13.2 Print Quick Actions

```javascript
if (validationResults.summary.errors > 0 || validationResults.summary.warnings > 0) {
  console.log('');
  console.log('🎯 Quick Actions:');
  console.log('');
  
  if (validationResults.summary.errors > 0) {
    console.log('1. Review errors in report:');
    console.log(`   cat ${outputPath}`);
    console.log('');
  }
  
  const hasAutoFixable = validationResults.checks.metadataConsistency.errors.length > 0 ||
                         validationResults.checks.dependentsCalculation.errors.length > 0;
  
  if (hasAutoFixable && !FLAGS.fix) {
    console.log('2. Run auto-fix:');
    console.log('   /smartspec_validate_index --fix');
    console.log('');
  }
  
  if (FLAGS.report === 'summary') {
    console.log('3. Generate detailed report:');
    console.log('   /smartspec_validate_index --report=detailed');
    console.log('');
  }
}
```

---

## 14. Exit with Appropriate Code

```javascript
// Exit codes:
// 0 = Valid (no errors, no warnings)
// 1 = Warnings (no errors, but warnings found)
// 2 = Errors (errors found)

let exitCode = 0;

if (validationResults.summary.errors > 0) {
  exitCode = 2;
} else if (validationResults.summary.warnings > 0) {
  exitCode = 1;
}

console.log('');
console.log(`Exit code: ${exitCode}`);

process.exit(exitCode);
```

---

## 15. Examples

### Example 1: Basic Validation

```bash
/smartspec_validate_index
```

**Output:**
```
✅ Found SPEC_INDEX at: .spec/SPEC_INDEX.json
✅ Loaded SPEC_INDEX.json
   Total specs: 42
✅ Initialized validation results

🔍 Check 1: File Existence
──────────────────────────────────────────────────
✅ All spec files exist

🔍 Check 2: Broken References
──────────────────────────────────────────────────
❌ Found 2 broken references
   - spec-feature-005 → spec-core-999
   - spec-feature-010 → spec-infra-050

... (other checks)

============================================================
VALIDATION COMPLETE
============================================================

❌ Status: ERRORS FOUND

📊 Health Score: 85/100
✅ Passed Checks: 6/8
❌ Errors: 3
⚠️  Warnings: 5

📄 Report: .spec/reports/validation-report-2025-01-04T10-30-00.md

============================================================

🎯 Quick Actions:

1. Review errors in report:
   cat .spec/reports/validation-report-2025-01-04T10-30-00.md

2. Run auto-fix:
   /smartspec_validate_index --fix

Exit code: 2
```

---

### Example 2: Validation with Auto-Fix

```bash
/smartspec_validate_index --fix
```

**Output:**
```
... (validation checks)

💾 Saving Fixed SPEC_INDEX
──────────────────────────────────────────────────
✅ Saved fixed SPEC_INDEX.json
   Applied 5 fixes

============================================================
VALIDATION COMPLETE
============================================================

⚠️  Status: WARNINGS FOUND

📊 Health Score: 95/100
✅ Passed Checks: 7/8
❌ Errors: 0
⚠️  Warnings: 5
🔧 Auto-Fixes Applied: 5

📄 Report: .spec/reports/validation-report-2025-01-04T10-35-00.md

============================================================

Exit code: 1
```

---

### Example 3: Detailed Report

```bash
/smartspec_validate_index --report=detailed
```

**Generates comprehensive report with:**
- Summary section
- Detailed results for each check
- Full error/warning descriptions
- Suggestions and examples
- Next steps

---

### Example 4: Custom Output Path

```bash
/smartspec_validate_index --fix --report=detailed --output=my-validation.md
```

**Output:**
```
... (validation and fixes)

📄 Report: my-validation.md

Exit code: 0
```

---

## 16. Best Practices

### When to Run Validation

**Recommended Schedule:**
- ✅ Before major releases
- ✅ After bulk spec changes
- ✅ Weekly (for active projects)
- ✅ Monthly (for stable projects)
- ✅ After team handover

**Triggers:**
- Suspecting INDEX issues
- After merging multiple branches
- Before generating tasks for large specs
- When dependency errors occur

---

### Interpreting Health Score

**Score Ranges:**
- **90-100:** Excellent - System is healthy
- **75-89:** Good - Minor issues to address
- **60-74:** Fair - Several issues need attention
- **45-59:** Poor - Significant problems
- **0-44:** Critical - Immediate action required

**Score Calculation:**
```
Base: 100 points
Deduct: 5 points per error
Deduct: 1 point per warning
Minimum: 0 points
```

---

### Auto-Fix Guidelines

**What Can Be Auto-Fixed:**
- ✅ Metadata counts (total_specs, by_status, by_repo)
- ✅ Dependents calculation
- ✅ Timestamps

**What Cannot Be Auto-Fixed:**
- ❌ Broken references (need manual spec creation/removal)
- ❌ Circular dependencies (need manual dependency removal)
- ❌ Duplicate specs (need manual merge/rename)
- ❌ Missing files (need manual file creation/INDEX update)

**Recommendation:**
- Always run without --fix first
- Review what will be fixed
- Then run with --fix
- Re-validate after fixing

---

### Handling Common Issues

#### Issue: Broken References

**Cause:** Spec deleted but still referenced

**Fix:**
```bash
# Option 1: Create missing spec
/smartspec_generate_spec "Missing Spec Title"

# Option 2: Remove reference
/smartspec_edit_spec specs/feature/spec-005-payment
# Remove spec-core-999 from dependencies
```

---

#### Issue: Circular Dependencies

**Cause:** Specs depend on each other in a cycle

**Fix:**
```bash
# Identify cycle: A → B → C → A
# Break by removing one dependency

/smartspec_edit_spec specs/core/spec-A
# Remove spec-C from dependencies
```

---

#### Issue: Duplicate Specs

**Cause:** Multiple specs for same feature

**Fix:**
```bash
# Option 1: Merge specs
# Combine content and delete one

# Option 2: Rename/differentiate
/smartspec_edit_spec specs/feature/spec-010
# Change title to be more specific
```

---

#### Issue: Orphaned Specs

**Cause:** Spec not used by any other spec

**Fix:**
```bash
# Option 1: Deprecate if not needed
/smartspec_edit_spec specs/feature/spec-020
# Change status to "deprecated"

# Option 2: Find use case and add dependencies
# Link to relevant specs
```

---

## 17. Troubleshooting

### Error: SPEC_INDEX.json not found

**Solution:**
```bash
# Create SPEC_INDEX using generate_spec workflow
/smartspec_generate_spec "First Spec"

# Or specify custom path
/smartspec_validate_index --index=custom/path/SPEC_INDEX.json
```

---

### Error: Invalid JSON

**Solution:**
```bash
# Validate JSON syntax
cat .spec/SPEC_INDEX.json | jq .

# If corrupted, restore from backup
cp .smartspec/backups/SPEC_INDEX.backup-YYYYMMDD.json .spec/SPEC_INDEX.json
```

---

### Warning: High number of orphaned specs

**Cause:** Many specs not linked to others

**Solution:**
```bash
# Review orphaned specs
cat validation-report.md | grep "orphaned"

# For each orphaned spec:
# 1. Check if still needed
# 2. If yes, link to relevant specs
# 3. If no, deprecate

/smartspec_edit_spec specs/feature/spec-XXX
# Update status or add dependencies
```

---

## 18. Integration with CI/CD

### GitHub Actions Example

```yaml
name: Validate SPEC_INDEX

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Validate SPEC_INDEX
        run: |
          /smartspec_validate_index --report=detailed
      
      - name: Upload Report
        if: always()
        uses: actions/upload-artifact@v2
        with:
          name: validation-report
          path: .spec/reports/validation-report-*.md
      
      - name: Fail on Errors
        run: |
          if [ $? -eq 2 ]; then
            echo "❌ Validation failed with errors"
            exit 1
          fi
```

---

## 19. Summary

**This workflow provides:**
- ✅ Comprehensive validation (8 checks)
- ✅ Duplicate detection (ID, path, similar titles)
- ✅ Health score calculation
- ✅ Actionable recommendations
- ✅ Auto-fix support
- ✅ Detailed reporting
- ✅ CI/CD integration

**Use it to:**
- Maintain SPEC_INDEX integrity
- Detect issues early
- Prevent implementation blockers
- Keep system healthy
- Ensure team confidence

---

**Workflow Version:** 1.0.0  
**Last Updated:** 2025-01-04  
**Author:** SmartSpec Team